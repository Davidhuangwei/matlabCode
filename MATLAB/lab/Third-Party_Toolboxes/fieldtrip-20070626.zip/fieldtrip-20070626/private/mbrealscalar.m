function mbrealscalar(a)

mbreal(a);
mbscalar(a);
