function mbreal(a);

if ~isreal(a)
  error('Argument to mbreal must be real');
end
