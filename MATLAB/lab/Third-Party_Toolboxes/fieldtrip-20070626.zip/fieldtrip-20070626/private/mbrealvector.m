function mbrealvector(a);

mbvector(a);
mbreal(a);
