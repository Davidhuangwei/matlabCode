it = it+1;
inferQX
inferQL
inferQns
inferQpi
inferQnu
inferpsii
infermcl
