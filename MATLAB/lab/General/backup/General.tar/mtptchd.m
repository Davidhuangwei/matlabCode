function [yo,fo, phi]=mtptchd(varargin);
%function [yo, fo]=mtptchd(x,Res, Clu, nFFT,Fs,WinLength,nOverlap,NW,Detrend,nTapers, FreqRange);
% Multitaper coherence density for continuous and point process
%
% This basically does the same thing as mtptcsd, but scales
% the cross-spectra to become coherences

[x, Res, Clu, nFFT,Fs,WinLength,nOverlap,NW,Detrend,nTapers,nChannels, nClu, nSamples, ...
        nFFTChunks,winstep,select,nFreqBins,f,t] = mtparam_pt(varargin);
winstep = WinLength - nOverlap;
nChannelsAll = nChannels + nClu;
CluInd = unique(Clu);
[y fo] = mtptcsd(x,Res, Clu, nFFT,Fs,WinLength,nOverlap,NW,Detrend,nTapers);

yo = zeros(size(y));
if nargout>2 phi = zeros(size(y)); end
% main loop
for Ch1 = 1:nChannelsAll
	for Ch2 = 1:nChannelsAll
		
		if (Ch1 == Ch2)
			% for diagonal elements (i.e. power spectra) leave unchanged
			yo(:,Ch1, Ch2) = y(:,Ch1, Ch2);
		else
			% for off-diagonal elements, scale
            		norm = (y(:,Ch1,Ch1) .* y(:,Ch2,Ch2));
            
	    		yo(:,Ch1, Ch2) = (abs(y(:,Ch1, Ch2))).^2 ./ norm;
            		if nargout>2
                 		phi(:,Ch1,Ch2) = angle(y(:,Ch1, Ch2) ./sqrt(norm) );
            		end
%	    		yo(:,Ch1, Ch2) = abs(y(:,Ch1, Ch2)).^2 ...
% 				./ sqrt(y(:,Ch1,Ch1) .* y(:,Ch2,Ch2));
    		end
	end
end
			
% plot stuff if required

if (nargout<1)
	PlotMatrix(fo,yo);
end;
