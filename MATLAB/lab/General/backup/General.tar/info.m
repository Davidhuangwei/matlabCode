function info(x)

fprintf('\nmax=%d',max(x));
fprintf('\nmin=%d',min(x));
size(x)

