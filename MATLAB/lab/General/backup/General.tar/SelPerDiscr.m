% selects discrete events within Periods 
function [y, ind]=SelPerDiscr(x,Periods, WhereFlag)
nPeriods = size(Periods,1);
%x = sort(x);
nTimeBins = max(x);
ind = [];


    if WhereFlag
        for p=1:nPeriods
            ind = [ind; find(x>Periods(p,1) & x<Periods(p,2))];
        end
        
    else
        ind = [ind; find(x > 1 & x < Periods(1,1))];
        if (nPeriods>1)
            for  p=1:nPeriods-1      
                ind = [ind; find(x > Periods(p,2) & x<Periods(p+1,1))];
            end
        end
        ind = [ind; find(x > Periods(end,2) & x<nTimeBins)];
        
    end
    
y = x(ind);       
return