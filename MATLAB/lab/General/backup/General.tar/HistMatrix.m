% HistMatrix(Y, nBins, Labels)
% Takes an array Y and makes a plot of histograms
%
function HistMatrix(Y, nBins, Labels)

if (ndims(Y) == 4)
	nPlotsX = size(Y,3);
	nPlotsY = size(Y,4);
elseif (ndims(Y) == 3)
	nPlotsX = size(Y,2);
	nPlotsY = size(Y,3);
elseif (ndims(Y) == 2)
    Y = permute(shiftdim(Y,-1),[2 3 1]);
  	nPlotsX = size(Y,2);
	nPlotsY = size(Y,3);

else
	error('Input Y must have 2 to 4 dimensions');
end


% now make the plot matrix
for i=1:nPlotsX
	for j=1:nPlotsY
		% select correct subplot
		subplot(nPlotsY, nPlotsX, i + (j-1)*nPlotsX);
        
        if ndims(Y)<4
            thisGraph = Y(:,i,j);
    		hist(thisGraph,nBins);
    		axis tight
        else
            thisGraph = sq(Y(:,:,i,j));
            [thishist, bins] = hist(thisGraph,nBins);
            imagesc(thishist);
        end
        if nargin>2 
            xlabel(Labels{i,j});
        end
	end
end
