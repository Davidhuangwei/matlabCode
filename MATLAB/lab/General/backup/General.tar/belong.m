function res = belong(x,a,b)
if (x>a & x<b) 
   res=1;
else
   res=0;
end
