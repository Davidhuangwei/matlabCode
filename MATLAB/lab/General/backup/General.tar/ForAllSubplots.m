% ForAllSubplots(Command)
%
% Selects every subplot of the current figure
% and executes Command.

function Out = ForAllSubplots(Command,nPlots);

children = get(gcf, 'Children')';
for i=1:nPlots %length(children) -- wierd bug - number of Children more than number of supblots...
	set(gcf, 'CurrentAxes', children(i));
    %clear o;
    eval(Command);
    %if exist('o')
    %	Out{i} = o;
    %end
end;