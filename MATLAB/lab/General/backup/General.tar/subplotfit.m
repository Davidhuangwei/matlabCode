%function subplotfit(index,totnum)
function subplotfit(index,totnum)
if totnum~=3
    xnum=ceil(totnum/sqrt(totnum));
    ynum=ceil(totnum/xnum);
    subplot(ynum,xnum,index);
else
    subplot(3,1,index);
end