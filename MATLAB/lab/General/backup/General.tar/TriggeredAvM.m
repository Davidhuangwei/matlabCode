%function [EegSegAv EegSegStd EegSTrange] = TriggeredAvM(Eeg,T,win,sr,nChannels,method)
% trigered averages multiple channels from file or matrix
% within a window of win (in msec)
% method : 1, to load all channels for each segment around trigger (if nChannels/nTriggers is large)
%               2, to load each channel and trigger average it separately (use that if nChannels/nTriggers is small)

function [EegSegAv, EegSegStd, Trange]=TriggeredAvM(Eeg,T,win,sr,nChannels,method)

if (length(win)==1)
    win = [win win];
end
swin = round(win*sr/1000);
Srange = [-swin(1):swin(end)];
nsamples = length(Srange);
Trange = linspace(-win(1),win(end),length(Srange))*1000/sr;
iseeg=1;
 
if ~isstr(Eeg)
    [EegSegAv EegSegStd] = TriggeredAv(Eeg,swin(1),swin(end),T);
else
    if ~strcmp(Eeg(end-3:end),'.eeg')
        filebase = Eeg;
    else
        filebase = Eeg(1:end-4);
    end
    if isempty(nChannels)
        Par = LoadPar([filebase '.par']);
        nChannels =Par.nChannels;
    end
    
    maxSample = FileLength([filebase '.eeg']) /nChannels/2;
    T = T(find(T>swin(1)+1 & T<maxSample-swin(end)));
    %     EegSeg=zeros(length(Srange),nChannels,length(T));
    EegSegAv = zeros(length(Srange),nChannels);
    EegSegStd = zeros(length(Srange),nChannels);
    if method == 1
        nT = length(T);
        for d=1:nT
            startpos = (T(d)-swin(1))*nChannels*2;
            tmpeeg = bload([filebase '.eeg'], [nChannels nsamples], startpos,'int16');
            tmpeeglong = bload([filebase '.eeg'], [nChannels nsamples*5], startpos,'int16');
            tmpeeg = tmpeeg - repmat(mean(tmpeeglong,2),1,nsamples);
            EegSegAv = EegSegAv+tmpeeg(:,:)';
            EegSegStd = EegSegStd+tmpeeg(:,:)'.^2;
        end
        EegSegAv = EegSegAv;
        EegSegStd = EegSegStd./nT - EegSegAv.^2;
    else
        
        for i=1:nChannels 
            eeg = readsinglech([filebase '.eeg'], nChannels,i);
            [EegSegAv(:,i) EegSegStd(:,i)] = TriggeredAv(eeg, swin(1),swin(end),T);
        end
    end
end