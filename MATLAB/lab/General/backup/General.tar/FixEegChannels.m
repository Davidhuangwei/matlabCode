%function Eeg = FixEegChannels(Eeg, ChannelsToFix, Method)
function Eeg = FixEegChannels(Eeg, ChannelsToFix, Method)

if nargin<3 | isempty(nargin) Method ='spline'; end
   
if isstr(Eeg)
    filename = Eeg;
    Par = ParLoad([filename '.par']);
    nChannels = Par.nChannels;
else
    nChannels = min(size(Eeg));
    if (size(Eeg,1)>nChannels)
        Eeg = Eeg';
    end    
end
  
AllChannels = [1:nChannels];
GoodChannels = setdiff(AllChannels, ChannelsToFix);

if isstr(Eeg)
    Eeg = readmulti([filename '.eeg'], nChannels, GoodChannels);
else
    Eeg = Eeg(GoodChannels,:);
end

Eeg = interp1(GoodChannels, Eeg, AllChannels, Method);




    