% computes the available memory in bytes
function HowMuch = FreeMemory


unix('vmstat > curmemory');
[jk, mf] = unix('awgetxy curmemory 3 5');
[jk, mc] = unix('awgetxy curmemory 3 7');
unix('rm curmemory');
HowMuch=str2num(mf)+str2num(mc);
