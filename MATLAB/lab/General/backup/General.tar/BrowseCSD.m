%function BrowseCSD(filename,nChannels,WhichChannels,win, start,csdstep,filter)
% browses csd and dat(or eeg if no dat) of the filename files
% of WhichChannels and stepping by win (in msec)
function BrowseCSD(filename,varargin)

Par =LoadPar([filename '.par']);
[nChannels, WhichChannels,win, start, csdstep,filter] = ...
    DefaultArgs(varargin, {Par.nChannels,Par.ElecGp,  1000, 1, 2,200});
    
figure
finfo = dir([filename '.eeg']);

flength = finfo.bytes/2/nChannels;
    
if (length(start)>1) % if start indicates the times of windows
    WinsStart = start - round(win/2/1000);
    nWins = length(start);
else
    nWins = round((flength/1.25- start)/win);
    WinsStart = 1:nWins;
    WinsStart = start+(WinsStart-1)*win/1000;
end

% keyboard

for i=1:nWins
    clf
    segment = [WinsStart(i), 0, win];
    ViewSegCSD(filename,nChannels,WhichChannels,segment,csdstep,filter);
    pause
end
