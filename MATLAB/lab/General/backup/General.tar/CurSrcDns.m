%function [csd, newtrange, newchrange] = CurSrcDns(eeg,trange,type,chnum,chanrange,samplerate, step, ColorRange)
function [csd, newtrange, newchrange] = CurSrcDns(eeg,varargin)
method =2;
if size(eeg,1)<size(eeg,2)
    eeg  = eeg';
end
[trange,type,chnum,chanrange,samplerate, step,ColorRange] = ...
    DefaultArgs(varargin, {[], 'c',size(eeg,2), [1:size(eeg,2)], 1250, 2, []}); 
% if isempty(trange)

if isempty(trange)
 trange=[1:size(eeg,1)]/(samplerate/1000);
end
% end
csd=eeg;
if (method == 1)
    csd=-diff(csd,2,2);
else
    ch=[step+1:chnum-step];
    csd = csd(:,ch+step) - 2*csd(:,ch) + csd(:,ch-step);
    csd = -csd/(step^2);
end

%m=MeanSmoothMany(trange,eeg,5);
%csd=interp2(eeg,'cubic');
%csd=interp2(eeg,'nearest');

% [nt, nch] = meshgrid(newtrange, newchrange); 
% csd=interp2(ch, trange, csd', nt, nch, 'linear');

if nargout==0
    
    csd=interp2(csd, 'linear');
    %csd =csd(:,1:2:end);
    %csd=interp2(csd,'cubic');
    %csd=interp2(csd,'nearest');
    newtrange=linspace(trange(1),trange(end),size(csd,1));
    newchrange=linspace(ch(1), ch(end), size(csd,2));

    if (type=='c')
        pcolor(newtrange,newchrange,csd');
        set(gca,'YTick', newchrange(1:2:end));
        shading interp
        axis tight
        set(gca,'ydir','rev');
        %         colorbar
        if (isempty(ColorRange))
            cx =caxis;
            cxmax = max(abs(cx));
            caxis([-cxmax cxmax]);
        else
            caxis(ColorRange);
        end
    elseif (type=='l')
        spacing= mean(max(csd,[],1)-min(csd,[],1)) ;
        plot(newtrange,csd'-repmat(newchrange*spacing,length(newtrange),1)','k'); 
    end
end
