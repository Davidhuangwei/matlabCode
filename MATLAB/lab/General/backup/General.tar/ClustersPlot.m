function ClustersPlot(filename, ElecID, ProjectDim)

Fet = LoadFet([filename '.fet.' num2str(ElecID)]);
Par = LoadPar([filename '.par']);
UseCh = [1:3*Par.nChannels];

Clu = load([filename '.clu.' num2str(ElecID)]);
numClu = Clu(1);
Clu = Clu(2:end);

if isstr(ProjectDim)
    if strcmp(ProjectDim, 'pca')
        meanFet =[];
        for c=2:numClu
            meanFet = [meanFet; mean(Fet(find(Clu==c),UseCh),1)];
        end
        [pc ev explvar] = pcacov(cov(meanFet));
        NewFet = pc(:,1:2)'*Fet(:,UseCh)';
    end
    
else
    NewFet = Fet(:,ProjectDim)';
end
        
for c = 2:numClu
    plot(NewFet(1,find(Clu==c)),NewFet(2,find(Clu==c)),'.', ...
        'Color',rand(1,3));
    hold on
end
    
